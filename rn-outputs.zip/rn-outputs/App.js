import React, { useState, useEffect } from 'react';
import { Platform, SafeAreaView, ScrollView, Text, StyleSheet, View, TouchableOpacity, Image, ImageBackground, Modal, Alert, TextInput } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import AsyncStorage from '@react-native-async-storage/async-storage';

// Mock server using AsyncStorage
const api = {
  sendOrder: async (order) => {
    try {
      const existingOrders = await AsyncStorage.getItem('kitchenOrders');
      const orders = existingOrders ? JSON.parse(existingOrders) : [];
      const newOrder = {
        ...order,
        id: Date.now(),
        date: new Date().toLocaleString(),
        status: 'pending'
      };
      orders.push(newOrder);
      await AsyncStorage.setItem('kitchenOrders', JSON.stringify(orders));
      return true;
    } catch (error) {
      console.error('Error sending order:', error);
      return false;
    }
  }
};

// Login Screen
const LoginScreen = ({ navigation }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = async () => {
    if (username && password) {
      try {
        await AsyncStorage.setItem('user', JSON.stringify({ username }));
        navigation.navigate('Home');
      } catch (error) {
        Alert.alert("Error", "Failed to save user data");
      }
    } else {
      Alert.alert("Error", "Please enter both username and password");
    }
  };

  return (
    <ImageBackground
      source={{ uri: 'https://via.placeholder.com/150' }}
      style={styles.backgroundImage}
      resizeMode="cover"
    >
      <View style={styles.overlay}>
        <SafeAreaView style={styles.container}>
          <ScrollView contentContainerStyle={styles.scrollContent}>
            <Image
              source={{ uri: 'https://via.placeholder.com/150' }}
              style={styles.logo}
              resizeMode="contain"
            />
            
            <Text style={styles.title}>Login to Git Grubs</Text>
            
            <TextInput
              style={styles.input}
              placeholder="Username"
              value={username}
              onChangeText={setUsername}
              autoCapitalize="none"
            />
            
            <TextInput
              style={styles.input}
              placeholder="Password"
              value={password}
              onChangeText={setPassword}
              secureTextEntry
            />
            
            <TouchableOpacity
              style={styles.button}
              onPress={handleLogin}
            >
              <Text style={styles.buttonText}>Login</Text>
            </TouchableOpacity>
          </ScrollView>
        </SafeAreaView>
      </View>
    </ImageBackground>
  );
};

// HomeScreen
const HomeScreen = ({ navigation }) => {
  return (
    <ImageBackground
      source={{ uri: 'https://via.placeholder.com/150' }}
      style={styles.backgroundImage}
      resizeMode="cover"
    >
      <View style={styles.overlay}>
        <SafeAreaView style={styles.container}>
          <ScrollView 
            contentContainerStyle={styles.scrollContent}
            showsVerticalScrollIndicator={false}
          >
            <Image
              source={{ uri: 'https://via.placeholder.com/150' }}
              style={styles.logo}
              resizeMode="contain"
            />

            <Text style={styles.title}>Welcome to Git Grubs</Text>

            <Text style={styles.introText}>
              Late night food for hungry developers
            </Text>
            
            <TouchableOpacity
              style={styles.button}
              onPress={() => navigation.navigate('Menu')}
            >
              <Text style={styles.buttonText}>View Menu</Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[styles.button, { backgroundColor: 'green' }]}
              onPress={() => navigation.navigate('OrderHistory')}
            >
              <Text style={styles.buttonText}>View Order History</Text>
            </TouchableOpacity>
          </ScrollView>
        </SafeAreaView>
      </View>
    </ImageBackground>
  );
};

// MenuScreen with Cart
const MenuScreen = ({ navigation }) => {
  const [cart, setCart] = useState([]);
  const [customerName, setCustomerName] = useState('');
  const [showNameInput, setShowNameInput] = useState(false);

  const addToCart = (item) => {
    setCart([...cart, item]);
  };

  const removeFromCart = (index) => {
    const newCart = [...cart];
    newCart.splice(index, 1);
    setCart(newCart);
  };

  const calculateTotal = () => {
    return cart.reduce((total, item) => {
      const price = parseFloat(item.price.replace('$', ''));
      return total + price;
    }, 0).toFixed(2);
  };

  const handleCheckout = async () => {
    if (cart.length === 0) {
      Alert.alert("Empty Cart", "Your cart is empty. Please add items before checkout.");
      return;
    }
    
    if (!customerName) {
      setShowNameInput(true);
      return;
    }
    
    try {
      const order = {
        items: cart,
        total: calculateTotal(),
        customerName
      };
      
      // Save to local history
      const existingHistory = await AsyncStorage.getItem('orderHistory');
      const history = existingHistory ? JSON.parse(existingHistory) : [];
      await AsyncStorage.setItem('orderHistory', JSON.stringify([...history, {
        ...order,
        id: Date.now(),
        date: new Date().toLocaleString()
      }]));
      
      // Send to kitchen
      const success = await api.sendOrder(order);
      
      if (!success) throw new Error('Failed to send to kitchen');
      
      setCart([]);
      setCustomerName('');
      Alert.alert(
        "Order Confirmed!",
        `Thank you, ${customerName}! Your order total is $${calculateTotal()}`
      );
    } catch (error) {
      Alert.alert(
        "Order Submitted",
        `Your order was saved but couldn't reach the kitchen. Please notify staff.`
      );
    }
  };

  return (
    <ImageBackground
      source={{ uri: 'https://via.placeholder.com/150' }}
      style={styles.backgroundImage}
    >
      <SafeAreaView style={styles.container}>
        <ScrollView 
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={true}
        >
          <Text style={styles.title}>Git Grubs Menu</Text>
          
          {showNameInput && (
            <View style={styles.nameInputContainer}>
              <TextInput
                style={styles.input}
                placeholder="Enter your name"
                value={customerName}
                onChangeText={setCustomerName}
                onSubmitEditing={() => {
                  if (customerName) {
                    setShowNameInput(false);
                    handleCheckout();
                  }
                }}
              />
              <TouchableOpacity
                style={[styles.button, { marginTop: 10 }]}
                onPress={() => {
                  if (customerName) {
                    setShowNameInput(false);
                    handleCheckout();
                  }
                }}
              >
                <Text style={styles.buttonText}>Confirm Name</Text>
              </TouchableOpacity>
            </View>
          )}

          <View style={styles.menuItemContainer}>
            <Text style={styles.menuSection}>Pizza Slices:</Text>
            
            <TouchableOpacity onPress={() => addToCart({ name: "Cheese Pizza", price: "$6.00" })}>
              <Text style={styles.menuItem}>- Cheese: $6.00</Text>
            </TouchableOpacity>
            
            <TouchableOpacity onPress={() => addToCart({ name: "Pepperoni Pizza", price: "$7.00" })}>
              <Text style={styles.menuItem}>- Pepperoni: $7.00</Text>
            </TouchableOpacity>
            
            <TouchableOpacity onPress={() => addToCart({ name: "Pepperoni and Sausage Pizza", price: "$8.00" })}>
              <Text style={styles.menuItem}>- Pepperoni and Sausage: $8.00</Text>
            </TouchableOpacity>

            <View style={styles.separator}></View>

            <Text style={styles.menuSection}>Sandwiches:</Text>
            
            <TouchableOpacity onPress={() => addToCart({ name: "Chicken Sandwich", price: "$5.00" })}>
              <Text style={styles.menuItem}>- Chicken Sandwich: $5.00</Text>
            </TouchableOpacity>
            
            <TouchableOpacity onPress={() => addToCart({ name: "Grilled Cheese Sandwich", price: "$5.00" })}>
              <Text style={styles.menuItem}>- Grilled Cheese Sandwich: $5.00</Text>
            </TouchableOpacity>
            
            <View style={styles.separator}></View>

            <Text style={styles.menuSection}>Wings:</Text>
            
            <TouchableOpacity onPress={() => addToCart({ name: "6 Piece Wings", price: "$8.00" })}>
              <Text style={styles.menuItem}>- 6 Piece Wings: $8.00</Text>
            </TouchableOpacity>
            
            <TouchableOpacity onPress={() => addToCart({ name: "12 Piece Wings", price: "$15.00" })}>
              <Text style={styles.menuItem}>- 12 Piece Wings: $15.00</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>

        {/* Cart Section */}
        <View style={styles.cartContainer}>
          <Text style={styles.cartTitle}>Your Cart ({cart.length} items)</Text>
          
          {cart.length > 0 ? (
            <>
              {cart.map((item, index) => (
                <View key={index} style={styles.cartItem}>
                  <Text style={styles.cartItemText}>{item.name} - {item.price}</Text>
                  <TouchableOpacity onPress={() => removeFromCart(index)}>
                    <Text style={styles.removeItemText}>Remove</Text>
                  </TouchableOpacity>
                </View>
              ))}
              
              <Text style={styles.cartTotal}>Total: ${calculateTotal()}</Text>
              
              <TouchableOpacity
                style={[styles.button, { backgroundColor: 'green' }]}
                onPress={handleCheckout}
              >
                <Text style={styles.buttonText}>Checkout</Text>
              </TouchableOpacity>
            </>
          ) : (
            <Text style={styles.emptyCartText}>Your cart is empty</Text>
          )}
        </View>
      </SafeAreaView>
    </ImageBackground>
  );
};

// Order History Screen
const OrderHistoryScreen = () => {
  const [orderHistory, setOrderHistory] = useState([]);

  useEffect(() => {
    const loadOrderHistory = async () => {
      try {
        const history = await AsyncStorage.getItem('orderHistory');
        if (history) {
          setOrderHistory(JSON.parse(history));
        }
      } catch (error) {
        Alert.alert("Error", "Failed to load order history");
      }
    };
    
    loadOrderHistory();
  }, []);

  return (
    <ImageBackground
      source={{ uri: 'https://via.placeholder.com/150' }}
      style={styles.backgroundImage}
    >
      <SafeAreaView style={styles.container}>
        <ScrollView contentContainerStyle={styles.scrollContent}>
          <Text style={styles.title}>Your Order History</Text>
          
          {orderHistory.length > 0 ? (
            orderHistory.map((order) => (
              <View key={order.id} style={styles.orderCard}>
                <Text style={styles.orderDate}>{order.date}</Text>
                <Text style={styles.orderCustomer}>Name: {order.customerName}</Text>
                
                {order.items.map((item, index) => (
                  <Text key={index} style={styles.orderItem}>
                    {item.name} - {item.price}
                  </Text>
                ))}
                
                <Text style={styles.orderTotal}>Total: ${order.total}</Text>
              </View>
            ))
          ) : (
            <Text style={styles.emptyHistoryText}>No order history found</Text>
          )}
        </ScrollView>
      </SafeAreaView>
    </ImageBackground>
  );
};

// Navigation
const Stack = createStackNavigator();

const App = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    const checkLoginStatus = async () => {
      try {
        const user = await AsyncStorage.getItem('user');
        setIsLoggedIn(!!user);
      } catch (error) {
        console.error("Error checking login status:", error);
      }
    };
    
    checkLoginStatus();
  }, []);

  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName={isLoggedIn ? "Home" : "Login"}>
        <Stack.Screen name="Login" component={LoginScreen} options={{ headerShown: false }} />
        <Stack.Screen name="Home" component={HomeScreen} options={{ title: 'Git Grubs' }} />
        <Stack.Screen name="Menu" component={MenuScreen} options={{ title: 'Menu' }} />
        <Stack.Screen name="OrderHistory" component={OrderHistoryScreen} options={{ title: 'Order History' }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

// Styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  backgroundImage: {
    flex: 1,
    resizeMode: 'cover',
  },
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.4)',
  },
  scrollContent: {
    flexGrow: 1,
    padding: 20,
    paddingBottom: Platform.OS === 'ios' ? 40 : 20,
  },
  logo: {
    width: 150,
    height: 150,
    alignSelf: 'center',
    marginBottom: 30,
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    color: 'red',
    marginBottom: 20,
    textAlign: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    padding: 10,
    borderRadius: 10,
  },
  introText: {
    fontSize: 18,
    color: '#FFFFFF',
    marginBottom: 30,
    textAlign: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    padding: 10,
    borderRadius: 10,
  },
  button: {
    backgroundColor: 'red',
    padding: 15,
    borderRadius: 10,
    alignSelf: 'center',
    marginTop: 20,
    marginBottom: 20,
  },
  buttonText: {
    fontSize: 18,
    color: '#FFFFFF',
    fontWeight: 'bold',
  },
  menuItemContainer: {
    marginBottom: 20,
    width: '100%',
  },
  menuSection: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginTop: 15,
    marginBottom: 10,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    padding: 10,
    borderRadius: 10,
  },
  menuItem: {
    fontSize: 18,
    color: '#FFFFFF',
    marginBottom: 10,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    padding: 10,
    borderRadius: 10,
  },
  separator: {
    height: 1,
    backgroundColor: '#fff',
    marginVertical: 10,
  },
  input: {
    backgroundColor: 'white',
    padding: 15,
    borderRadius: 10,
    marginBottom: 15,
    width: '100%',
  },
  cartContainer: {
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    padding: 15,
    borderTopWidth: 1,
    borderTopColor: '#ccc',
  },
  cartTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 10,
  },
  cartItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  cartItemText: {
    fontSize: 16,
    color: 'white',
  },
  removeItemText: {
    fontSize: 14,
    color: 'red',
  },
  cartTotal: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'white',
    marginTop: 10,
    marginBottom: 15,
  },
  emptyCartText: {
    fontSize: 16,
    color: 'white',
    textAlign: 'center',
    marginVertical: 10,
  },
  orderCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.8)',
    borderRadius: 10,
    padding: 15,
    marginBottom: 15,
  },
  orderDate: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  orderCustomer: {
    fontSize: 16,
    marginBottom: 10,
  },
  orderItem: {
    fontSize: 14,
    marginLeft: 10,
    marginBottom: 5,
  },
  orderTotal: {
    fontSize: 16,
    fontWeight: 'bold',
    marginTop: 10,
    color: 'green',
  },
  emptyHistoryText: {
    fontSize: 18,
    color: 'white',
    textAlign: 'center',
    marginTop: 50,
  },
  nameInputContainer: {
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    padding: 15,
    borderRadius: 10,
    marginBottom: 20,
  },
});

export default App;